def add(a, b):
    return a + b

def main():
    result = add(2, 3)
    print(f"Result: {result}")

if __name__ == "__main__":
    main()
